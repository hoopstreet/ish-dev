#!/bin/sh
echo "🔍 Re-aligning Local iSH Storage..."

# Ensure directory integrity
mkdir -p /root/ish-dev/core /root/ish-dev/docs /root/ish-dev/recovery

# Force-pull any missing architectural files from Remote
git pull origin main --rebase

# Restore core automation logic if missing
git checkout core/ 2>/dev/null

# Clean up broken temp files
rm -rf /tmp/task_* /tmp/auto_script.sh

# Final Permission Lockdown
chmod +x /root/ish-dev/core/*.sh
chmod +x /root/ish-dev/core/*.py
ln -sf /root/ish-dev/core/menu.sh /usr/local/bin/hoopstreet

echo "✅ [SUCCESS] Deep Recovery & Merge Complete."
