#!/bin/sh
echo "Installing Hoopstreet Agent..."
curl -fsSL https://raw.githubusercontent.com/hoopstreet/ish-dev/main/installer.sh | sh
