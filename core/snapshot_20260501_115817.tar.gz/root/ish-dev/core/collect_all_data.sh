#!/bin/sh
# HOOPSTREET COMPLETE DATA COLLECTOR
# Gathers ALL code, configs, repos, and system info

echo "═══════════════════════════════════════════════════════"
echo "  📦 HOOPSTREET DATA COLLECTOR - COMPLETE SYSTEM DUMP"
echo "═══════════════════════════════════════════════════════"
echo ""

# Create output directory
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
OUTPUT_DIR="/tmp/hoopstreet_full_dump_$TIMESTAMP"
mkdir -p "$OUTPUT_DIR"

echo "📁 Output directory: $OUTPUT_DIR"
echo ""

# ============================================================
# 1. SYSTEM INFORMATION
# ============================================================
echo "📊 1. Gathering System Information..."
cat > "$OUTPUT_DIR/01_system_info.txt" << EOF
═══════════════════════════════════════════════════════════
SYSTEM INFORMATION
═══════════════════════════════════════════════════════════
Date: $(date)
Hostname: $(hostname)
User: $(whoami)
Shell: $SHELL
PATH: $PATH

Python Version: $(python3 --version 2>&1)
Pip Version: $(pip --version 2>&1)
Git Version: $(git --version 2>&1)

Memory Info:
$(free -h 2>/dev/null || echo "Not available")

Disk Info:
$(df -h 2>/dev/null | head -10)
EOF
# ============================================================
# 2. DIRECTORY STRUCTURE
# ============================================================
echo "📁 2. Capturing Directory Structure..."
# Create directory tree
find /root -maxdepth 3 -type d -name "ish-dev" -o -name "hoopstreet" -o -name "temp-tg" -o -name "projects" 2>/dev/null | head -20 > "$OUTPUT_DIR/02_directories.txt"
ls -la /root/ >> "$OUTPUT_DIR/02_directories.txt"

# ============================================================
# 3. HOOPSTREET AGENT FILES (COMPLETE)
# ============================================================
echo "🤖 3. Copying Hoopstreet Agent Files..."
mkdir -p "$OUTPUT_DIR/hoopstreet"
cp -r /root/hoopstreet/* "$OUTPUT_DIR/hoopstreet/" 2>/dev/null

# List all files
ls -la /root/hoopstreet/ > "$OUTPUT_DIR/03_hoopstreet_files.txt"
# ============================================================
# 4. ISH-DEV PROJECT FILES (COMPLETE)
# ============================================================
echo "📂 4. Copying ish-dev Project Files..."
mkdir -p "$OUTPUT_DIR/ish-dev"
cp -r /root/ish-dev/* "$OUTPUT_DIR/ish-dev/" 2>/dev/null

# List all files
ls -la /root/ish-dev/ > "$OUTPUT_DIR/04_ish-dev_files.txt"

# ============================================================
# 5. TEMP-TG REPOSITORY
# ============================================================
echo "📦 5. Copying temp-tg Repository..."
if [ -d "/root/temp-tg" ]; then
    mkdir -p "$OUTPUT_DIR/temp-tg"
    cp -r /root/temp-tg/* "$OUTPUT_DIR/temp-tg/" 2>/dev/null
    echo "temp-tg repository copied" > "$OUTPUT_DIR/05_temp-tg_status.txt"
else
    echo "temp-tg not found" > "$OUTPUT_DIR/05_temp-tg_status.txt"
fi

# ============================================================
# 6. CREDENTIALS (Masked - Safe)
# ============================================================
echo "🔐 6. Collecting Credentials Status (Masked)..."
if [ -d "/root/.hoopstreet" ]; then
    cp -r /root/.hoopstreet "$OUTPUT_DIR/06_credentials/" 2>/dev/null
    echo "Credentials directory found" > "$OUTPUT_DIR/06_creds_status.txt"
else
    echo "No credentials directory" > "$OUTPUT_DIR/06_creds_status.txt"
fi
# ============================================================
# 7. LOGS AND DNA
# ============================================================
echo "📝 7. Copying Logs and DNA..."
cp /root/ish-dev/DNA.md "$OUTPUT_DIR/07_DNA.md" 2>/dev/null
cp /root/ish-dev/ROADMAP.md "$OUTPUT_DIR/08_ROADMAP.md" 2>/dev/null
cp /root/ish-dev/logs.txt "$OUTPUT_DIR/09_logs.txt" 2>/dev/null
cp /root/ish-dev/status.json "$OUTPUT_DIR/10_status.json" 2>/dev/null

# ============================================================
# 8. GITHUB REPOSITORIES INFO
# ============================================================
echo "🐙 8. Fetching GitHub Repositories..."
# List all local git repos
find /root -name ".git" -type d 2>/dev/null | while read gitdir; do
    repo_dir=$(dirname "$gitdir")
    echo "Repository: $repo_dir" >> "$OUTPUT_DIR/11_local_git_repos.txt"
    cd "$repo_dir"
    echo "  Branch: $(git branch --show-current 2>/dev/null)" >> "$OUTPUT_DIR/11_local_git_repos.txt"
    echo "  Remote: $(git remote -v 2>/dev/null | head -1)" >> "$OUTPUT_DIR/11_local_git_repos.txt"
    echo "" >> "$OUTPUT_DIR/11_local_git_repos.txt"
done

# GitHub API
if [ -f /root/.secrets/github.token ]; then
    TOKEN=$(cat /root/.secrets/github.token)
    curl -s -H "Authorization: token $TOKEN" "https://api.github.com/user/repos?per_page=50" > "$OUTPUT_DIR/12_github_repos.json"
else
    curl -s "https://api.github.com/users/hoopstreet/repos?per_page=50" > "$OUTPUT_DIR/12_github_repos.json"
fi
# ============================================================
# 9. ALL PYTHON AND SHELL SCRIPTS (CONCATENATED)
# ============================================================
echo "📄 9. Concatenating all scripts..."
> "$OUTPUT_DIR/13_all_python_code.txt"
> "$OUTPUT_DIR/14_all_shell_code.txt"

# All Python files
find /root -name "*.py" -type f 2>/dev/null | while read pyfile; do
    echo "========== FILE: $pyfile ==========" >> "$OUTPUT_DIR/13_all_python_code.txt"
    cat "$pyfile" >> "$OUTPUT_DIR/13_all_python_code.txt" 2>/dev/null
    echo "" >> "$OUTPUT_DIR/13_all_python_code.txt"
done

# All Shell files
find /root -name "*.sh" -type f 2>/dev/null | while read shfile; do
    echo "========== FILE: $shfile ==========" >> "$OUTPUT_DIR/14_all_shell_code.txt"
    cat "$shfile" >> "$OUTPUT_DIR/14_all_shell_code.txt" 2>/dev/null
    echo "" >> "$OUTPUT_DIR/14_all_shell_code.txt"
done
# ============================================================
# 10. CREATE MASTER SUMMARY
# ============================================================
echo "📋 10. Creating Master Summary..."
cat > "$OUTPUT_DIR/00_MASTER_SUMMARY.txt" << EOF
═══════════════════════════════════════════════════════════
  HOOPSTREET COMPLETE SYSTEM DUMP - MASTER SUMMARY
═══════════════════════════════════════════════════════════

Generated: $(date)
Output Directory: $OUTPUT_DIR

═══════════════════════════════════════════════════════════
CONTENTS
═══════════════════════════════════════════════════════════

01_system_info.txt        - System configuration
02_directories.txt         - Directory structure
03_hoopstreet_files.txt    - Agent file list
04_ish-dev_files.txt       - Project file list
05_temp-tg_status.txt      - temp-tg repository
06_credentials/            - Credentials (masked)
07_DNA.md                  - Evolution log
08_ROADMAP.md              - Project roadmap
09_logs.txt                - Activity log
10_status.json             - System status
11_local_git_repos.txt     - Local git repositories
12_github_repos.json       - GitHub API response
13_all_python_code.txt     - ALL Python files concatenated
14_all_shell_code.txt      - ALL Shell scripts concatenated

hoopstreet/                - Complete agent files
ish-dev/                   - Complete project files
temp-tg/                   - Temporary repository

═══════════════════════════════════════════════════════════
STATISTICS
═══════════════════════════════════════════════════════════

EOF

# Add statistics
echo "Python files: $(find /root -name "*.py" 2>/dev/null | wc -l)" >> "$OUTPUT_DIR/00_MASTER_SUMMARY.txt"
echo "Shell files: $(find /root -name "*.sh" 2>/dev/null | wc -l)" >> "$OUTPUT_DIR/00_MASTER_SUMMARY.txt"
echo "Markdown files: $(find /root -name "*.md" 2>/dev/null | wc -l)" >> "$OUTPUT_DIR/00_MASTER_SUMMARY.txt"
echo "Git repositories: $(find /root -name ".git" 2>/dev/null | wc -l)" >> "$OUTPUT_DIR/00_MASTER_SUMMARY.txt"
echo "" >> "$OUTPUT_DIR/00_MASTER_SUMMARY.txt"
# ============================================================
# 11. CREATE COMPRESSED ARCHIVE
# ============================================================
echo "🗜️ 11. Creating compressed archive..."
cd /tmp
tar -czf "hoopstreet_full_dump_$TIMESTAMP.tar.gz" "hoopstreet_full_dump_$TIMESTAMP/" 2>/dev/null

echo ""
echo "═══════════════════════════════════════════════════════"
echo "  ✅ COLLECTION COMPLETE!"
echo "═══════════════════════════════════════════════════════"
echo ""
echo "📦 Archive: /tmp/hoopstreet_full_dump_$TIMESTAMP.tar.gz"
echo "📁 Folder: $OUTPUT_DIR"
echo ""

# ============================================================
# 12. DISPLAY QUICK PREVIEW
# ============================================================
echo "📋 QUICK PREVIEW:"
echo "───────────────────────────────────────────────────────────"
echo ""
echo "Latest DNA Log:"
tail -5 "$OUTPUT_DIR/07_DNA.md" 2>/dev/null || echo "No DNA log"
echo ""
echo "Agent Files:"
ls -la "$OUTPUT_DIR/hoopstreet/" 2>/dev/null | head -10
echo ""

echo "═══════════════════════════════════════════════════════"
echo "  📤 TO SHARE WITH ME:"
echo "═══════════════════════════════════════════════════════"
echo ""
echo "Option 1 - Upload the archive and share the link:"
echo "  curl -F 'file=@/tmp/hoopstreet_full_dump_$TIMESTAMP.tar.gz' https://0x0.st"
echo ""
echo "Option 2 - Base64 encode (then paste in chat):"
echo "  base64 -w 0 /tmp/hoopstreet_full_dump_$TIMESTAMP.tar.gz"
echo ""
echo "Option 3 - Copy individual files (smaller):"
echo "  cat \$OUTPUT_DIR/00_MASTER_SUMMARY.txt"
echo "  cat \$OUTPUT_DIR/07_DNA.md"
echo "  cat \$OUTPUT_DIR/08_ROADMAP.md"
echo ""
