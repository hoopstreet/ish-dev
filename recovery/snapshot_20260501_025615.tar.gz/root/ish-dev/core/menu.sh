#!/bin/sh
while true; do
    clear
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "🏀 HOOPSTREET AGENT v10.0"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "1. 💻 Code        - Execute multi-phase code"
    echo "2. 🔄 Sync        - Git push/pull"
    echo "3. 🔧 Heal        - Auto-fix common bugs"
    echo "4. 📊 Status      - Complete system status"
    echo "5. 🔗 Remote      - GitHub Projects"
    echo "6. 🔐 Credentials - Token Manager"
    echo "0. 🚪 Exit"
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    printf "👉 Choose (0-6): "
    read choice

    case "$choice" in
        1) 
            echo "Launching Code Executor..."
            sleep 1
            /root/ish-dev/core/code.sh
            ;;
        2) /root/ish-dev/core/sync.sh ;;
        3) /root/ish-dev/core/heal.sh ;;
        4) /root/ish-dev/core/status.sh ;;
        5) /root/ish-dev/core/remote.sh ;;
        6) /root/ish-dev/core/creds.sh ;;
        0) echo "Goodbye!"; exit 0 ;;
        *) echo "Invalid. Enter 0-6"; sleep 1 ;;
    esac
done

7. 🤖 AI          - AI Assistant & Code Predictor
8. 📈 Metrics     - Performance Dashboard
9. 💾 Backup      - Auto Backup & Recovery
10. 🐙 Webhook    - Telegram/Discord Alerts
11. 🐳 Docker     - Container Support
12. 🧪 Tests      - Run Test Suite
13. 📚 Help       - Documentation
14. 🔒 Security   - Encryption Manager
0. 🚪 Exit

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
