#!/usr/bin/env python3
"""
HOOPSTREET AI AGENT v10.1.0
Gemini-powered coding assistant for iSH
"""
import sys
import os
import subprocess
from datetime import datetime, timezone, timedelta

# Philippines Timezone
PHT = timezone(timedelta(hours=8))

# Try to import Gemini
try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

def get_gemini_key():
    """Get Gemini API key from credentials"""
    creds_file = "/root/.hoopstreet/creds/credentials.txt"
    if os.path.exists(creds_file):
        with open(creds_file, 'r') as f:
            for line in f:
                if line.startswith("GEMINI_API_KEY="):
                    return line.split('=', 1)[1].strip()
    return None

def chat_with_gemini(prompt):
    """Chat with Gemini AI"""
    if not GEMINI_AVAILABLE:
        return "❌ Gemini not installed. Run: pip install google-generativeai"
    
    api_key = get_gemini_key()
    if not api_key:
        return "❌ GEMINI_API_KEY not found. Add it via Option 6"
    
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel('gemini-pro')
    
    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"❌ Gemini error: {str(e)}"

def execute_code(code):
    """Execute multi-phase code (original smart_executor functionality)"""
    lines = code.strip().split('\n')
    phases = []
    current_phase = []
    
    for line in lines:
        if '# Phase' in line:
            if current_phase:
                phases.append('\n'.join(current_phase))
            current_phase = [line]
        else:
            current_phase.append(line)
    
    if current_phase:
        phases.append('\n'.join(current_phase))
    
    if not phases:
        phases = [code]
    
    print(f"\n📊 Detected {len(phases)} phase(s)\n")
    
    for i, phase_code in enumerate(phases, 1):
        print(f"\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"📌 PHASE {i}")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        
        tmp = f"/tmp/phase_{i}.sh"
        with open(tmp, 'w') as f:
            f.write(phase_code)
        
        result = subprocess.call(['sh', tmp])
        os.remove(tmp)
        
        if result == 0:
            print(f"✅ Phase {i} SUCCESS")
        else:
            print(f"❌ Phase {i} FAILED")
            if i < len(phases):
                print("⚠️ Stopping execution due to failure")
                break

def main():
    print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("🤖 HOOPSTREET AI AGENT v10.1.0")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("📋 MODES:")
    print("   1. 💬 Chat Mode - Ask Gemini AI anything")
    print("   2. 💻 Code Mode - Execute multi-phase code")
    print("   3. 🔧 Fix Mode - AI-powered code repair")
    print("   0. 🔙 Back to Main Menu")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    
    choice = input("\n👉 Choose mode (0-3): ").strip()
    
    if choice == '1':
        print("\n💬 CHAT MODE - Ask Gemini AI")
        print("Type 'exit' to return\n")
        while True:
            prompt = input("🧠 You: ")
            if prompt.lower() in ['exit', 'quit', 'back']:
                break
            print("\n🤖 Gemini: ", 

        
        if lines and lines[0] != 'BACK':
            execute_code('\n'.join(lines))
    
    elif choice == '3':
        print("\n🔧 FIX MODE - Paste broken code, AI will fix it")
        print("Type 'END' when done\n")
        lines = []
        while True:
            try:
                l = input()
                if l.strip() == 'END':
                    break
                lines.append(l)
            except EOFError:
                break
        
        if lines:
            broken_code = '\n'.join(lines)
            print("\n🤖 Analyzing and fixing...\n")
            fix_prompt = f"Fix this code and explain the issues:\n\n{broken_code}"
            print(chat_with_gemini(fix_prompt))
    
    else:
        return
    
    input("\nPress Enter to continue...")

if __name__ == "__main__":
    main()
