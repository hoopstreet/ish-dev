#!/usr/bin/env python3
import sys, os, subprocess, json, requests, time
from datetime import datetime

CREDS_FILE = "/root/.hoopstreet/creds/credentials.txt"

# OpenRouter keys (more reliable than Gemini)
OPENROUTER_KEYS = [
    "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",
    "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",
    "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"
]

def get_openrouter_key():
    # First try credentials file
    if os.path.exists(CREDS_FILE):
        with open(CREDS_FILE, 'r') as f:
            for line in f:
                if line.startswith('OPENROUTER_KEY='):
                    return line.split('=',1)[1].strip()
    # Use hardcoded keys as fallback
    for key in OPENROUTER_KEYS:
        if key and key.startswith('sk-or'):
            return key
    return None

def call_openrouter(prompt, model="openai/gpt-3.5-turbo"):
    """Call OpenRouter API with available keys"""
    key = get_openrouter_key()
    if not key:
        return "⚠️ No OpenRouter key found. Add via Option 6"
    
    url = "https://openrouter.ai/api/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://hoopstreet.ish",
        "X-Title": "Hoopstreet AI Agent"
    }
    data = {
        "model": model,
        "messages": [{"role": "user", "content": prompt[:2000]}],
        "max_tokens": 500,
        "temperature": 0.7
    }
    
    try:
        r = requests.post(url, headers=headers, json=data, timeout=30)
        if r.status_code == 200:
            return r.json()["choices"][0]["message"]["content"]
        return f"API Error {r.status_code}: {r.text[:100]}"
    except Exception as e:
        return f"Error: {str(e)[:100]}"

def analyze_project():
    results = ["📁 PROJECT ANALYSIS\n"]
    
    core_dir = "/root/ish-dev/core"
    if os.path.exists(core_dir):
        scripts = [f for f in os.listdir(core_dir) if f.endswith(('.sh','.py'))]
        results.append(f"📂 Core Scripts: {len(scripts)} files")
        for s in scripts[:8]:
            results.append(f"   • {s}")
    
    docs_dir = "/root/ish-dev/docs"
    if os.path.exists(docs_dir):
        docs = os.listdir(docs_dir)
        results.append(f"\n📚 Documentation: {len(docs)} files")
    
    # Check memory
    mem_file = "/root/ish-dev/memory/enterprise_memory.json"
    if os.path.exists(mem_file):
        try:
            with open(mem_file, 'r') as f:
                mem = json.load(f)
            results.append(f"\n💾 Memory: {len(mem)} stored items")
        except: pass
    
    return '\n'.join(results)

def analyze_github():
    try:
        r = requests.get("https://api.github.com/repos/hoopstreet/ish-dev", timeout=10)
        if r.status_code == 200:
            d = r.json()
            return f"""📦 Repository: {d['name']}
⭐ Stars: {d['stargazers_count']}
🍴 Forks: {d['forks_count']}
📝 Description: {d.get('description', 'N/A')[:150]}
🕐 Updated: {d.get('updated_at', 'N/A')[:10]}"""
        return f"GitHub API Error: {r.status_code}"
    except Exception as e:
        return f"Cannot reach GitHub: {str(e)[:50]}"

def run_cmd(cmd):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
        return r.stdout[:1000] if r.stdout else r.stderr[:300]
    except:
        return "Command failed"

def save_memory(user, response):
    mem_file = "/root/ish-dev/memory/enterprise_memory.json"
    mem = {}
    if os.path.exists(mem_file):
        try:
            with open(mem_file, 'r') as f:
                mem = json.load(f)
        except: pass
    mem[str(time.time())] = {
        "user": user[:200],
        "response": response[:200],
        "time": str(datetime.now())
    }
    with open(mem_file, 'w') as f:
        json.dump(mem, f, indent=2)

def main():
    os.system('clear')
    print("\n" + "="*55)
    print("🏢 HOOPSTREET AI AGENT v7.5 - OpenRouter")
    print("="*55)
    
    # Show API status
    key = get_openrouter_key()
    if key:
        print(f"✅ OpenRouter API: READY (using {key[:20]}...)")
        print("   Access to GPT-4, Claude, Llama, and more!")
    else:
        print("⚠️ No OpenRouter key found")
        print("💡 Get free credits at: https://openrouter.ai/keys")
    
    print("="*55)
    print("📋 COMMANDS:")
    print("   analyze    - Deep project analysis")
    print("   github     - GitHub repo stats")
    print("   status     - System status")
    print("   heal       - Auto-repair")
    print("   sync       - Git push")
    print("   ask <q>    - Ask AI anything")
    print("="*55)
    print("💡 Type 'menu' to exit")
    print("="*55)
    
    while True:
        try:
            u = input("\n⚡ ").strip()
            if not u: continue
            if u.lower() == 'menu':
                print("👋 Goodbye!")
                break
            
            print("\n🤔 Processing...")
            
            low = u.lower()
            if 'analyze' in low:
                print(analyze_project())
            elif 'github' in low:
                print(analyze_github())
            elif 'status' in low:
                print(run_cmd("cat /root/ish-dev/docs/status.json"))
            elif 'heal' in low:
                print(run_cmd("sh /root/ish-dev/core/heal.sh"))
            elif 'sync' in low:
                print(run_cmd("sh /root/ish-dev/core/sync.sh"))
            elif low.startswith('ask '):
                q = u[4:]
                print("\n💬 AI: ", end="")
                print(call_openrouter(q))
            else:
                # Natural language understanding
                if 'what is' in low or 'tell me' in low or 'explain' in low:
                    print("\n💬 AI: ", end="")
                    print(call_openrouter(u))
                else:
                    print(f"🤔 Try: analyze, github, status, heal, sync, or ask <question>")
            
            # Save conversation
            save_memory(u, "processed")
            
        except KeyboardInterrupt:
            print("\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()
